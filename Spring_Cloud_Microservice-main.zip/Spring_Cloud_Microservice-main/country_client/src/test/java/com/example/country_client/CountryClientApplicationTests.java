package com.example.country_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
